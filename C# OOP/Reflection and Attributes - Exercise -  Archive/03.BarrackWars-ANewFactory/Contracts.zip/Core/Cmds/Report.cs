﻿namespace _03.BarrackWars_ANewFactory.Core.Cmds
{
    using _03BarracksFactory.Contracts;

    public class Report: Command
    {
        public Report(string[] data, IRepository repository, IUnitFactory unitFactory) : base(data, repository, unitFactory)
        {
        }

        public override string Execute()
            => this.Repository.Statistics;
    }
}
