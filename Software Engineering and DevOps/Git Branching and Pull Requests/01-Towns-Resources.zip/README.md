## Towns
# Exercise for students in the teamwork course at SoftUni-Svetlina @Software Engineering cource

# Roles
  Stephan takes the role “Editor”.
  Peter takes the role “Shiffler”.
  Maria takes the role “Styler”.
